#ifndef WIZARD_H
#define WIZARD_H
#include "Creature.h"

using namespace std;

//declaring derived class
class Wizard: public Creature
{
private:
    //declaring data members
    bool wand;
public:
    //default constructor
    Wizard();
    //non-default constructor
    Wizard(string name, double hitPoints, double strength, bool attackingStatus, bool wand);
    //setter
    void setWand(bool wand);
    //getter
    bool getWand();
    //destructor
    ~Wizard();
    //function to attack enemy
    void attack(Creature* enemy, int round);

    //function to display the status of the character
    void display();
};

#endif
