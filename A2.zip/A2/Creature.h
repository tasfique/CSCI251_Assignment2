#ifndef CREATURE_H
#define CREATURE_H

using namespace std;

//declaring the base class
class Creature
{
private:
    //declaring data members
    string name;
    double hitPoints;
    double strength;
    bool attackingStatus;
public:
    //default constructor
    Creature();
    //non-default constructor
    Creature(string name, double hitPoints, double strength, bool attackingStatus);
    //setters
    void setName(string name);
    void setHitPoints(double hitPoints);
    void setStrength(double strength);
    void setAttackingStatus(bool attackingStatus);
    //getters
    string getName();
    double getHitPoints();
    double getStrength();
    double getAttackingStatus();
    //destructor
    virtual ~Creature();
    //pure virtual function
    virtual void display()=0;
    virtual void attack();
};

#endif
