#include <iostream>
#include "Creature.h"

 //default constructor
    Creature::Creature()
    {
        name = "None";
        hitPoints = 0;
        strength = 0;
        attackingStatus = true;
    }

    //non-default constructor
    Creature::Creature(string name, double hitPoints, double strength, bool attackingStatus)
    {
        this->name = name;
        this->hitPoints = hitPoints;
        this->strength = strength;
        this->attackingStatus = attackingStatus;
    }

    //setters
    void Creature::setName(string name)
    {
        this->name = name;
    }

    void Creature::setHitPoints(double hitPoints)
    {
        this->hitPoints = hitPoints;
    }

    void Creature::setStrength(double strength)
    {
        this->strength=strength;
    }

    void Creature::setAttackingStatus(bool attackingStatus)
    {
        this->attackingStatus=attackingStatus;
    }

    //getters
    string Creature::getName()
    {
        return name;
    }

    double Creature::getHitPoints()
    {
        return hitPoints;
    }

    double Creature::getStrength()
    {
        return strength;
    }

    double Creature::getAttackingStatus()
    {
        return attackingStatus;
    }

    //destructor
    Creature::~Creature() {}

    //pure virtual function
    void Creature::display() {}

    void Creature::attack() {}
