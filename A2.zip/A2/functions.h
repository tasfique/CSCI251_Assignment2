#ifndef FUNCTIONS_H
#define FUNCTIONS_H
#include "Elf.h"
//implementing friend function
void initialStatus(Elf elf, Dwarf dwarf);

#endif
