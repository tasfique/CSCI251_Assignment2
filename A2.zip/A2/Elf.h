#ifndef ELF_H
#define ELF_H
#include "Creature.h"
#include "Dwarf.h"

//declaring derived class
class Elf: public Creature
{
    //friend function prototype
    friend void initialStatus(Elf elf, Dwarf dwarf);
private:
    //declaring data members
    double attackingSpeed;
public:
    //default constructor
    Elf();
    //default constructor
    Elf(string name, double hitPoints, double strength, bool attackingStatus, double attackingSpeed);
    //setter
    void setAttackingSpeed(double attackingSpeed);
    //getter
    double getAttackingSpeed();
    //destructor
    ~Elf();
    //function to attack an enemy
    void attack(Creature* enemy, int round);
    //function to display the status of the character
    void display();
    //implementing overloaded operator+
    Elf operator+(Elf elf);
};

#endif
