#include <iostream>
#include "Demon.h"

//default constructor
    Demon::Demon():Creature("Demon", 100, 20, true)
    {
        negativeAura=false;
    }

    //non-default constructor
    Demon::Demon(string name, double hitPoints, double strength, bool attackingStatus, bool negativeAura):Creature(name, hitPoints, strength, attackingStatus), negativeAura(negativeAura){}

    //setter
    void Demon::setNegativeAura(bool negativeAura)
    {
        this->negativeAura = negativeAura;
    }

    //getter
    bool Demon::getNegativeAura()
    {
        return negativeAura;
    }

    //destructor
    Demon::~Demon(){}

    //demon has negative aura as his special attribute. Every 3 rounds Demon steals 3 strengths from an enemy and adds it to its own strength. Also, demon inflicts additional 50 damage with 5% chance
    void Demon::attack(Creature* enemy, int round)
    {
        if(round%3==0)
        {
            setNegativeAura(true);
        }
        else
        {
            setNegativeAura(false);
        }

        if(getNegativeAura()==true)
        {
            enemy->setStrength(enemy->getStrength()-3);
            setStrength(getStrength()+3);
        }


        if(getAttackingStatus()==true)
        {
            int randomNum=(rand()%100)+1;
            if(randomNum<=95)
            {
                enemy->setHitPoints(enemy->getHitPoints() - getStrength());
            }
            else
            {
                enemy->setHitPoints(enemy->getHitPoints() - (getStrength()+50));
            }
        }
        else if(getAttackingStatus()==false)
        {
            setAttackingStatus(true);
        }
    }

    //function to display the status of the character
    void Demon::display()
    {
        cout << "Name: " << getName() << endl;
        cout << "Hit points: " << getHitPoints() << endl;
        cout << "Strength: " << getStrength() << endl;

        if(getAttackingStatus()==false)
            cout << "Attacking status: NO" << endl;
        else
            cout << "Attacking status: YES" << endl;

        if(getNegativeAura()==false)
            cout << "Negative aura: OFF" << endl;
        else
            cout << "Negative aura: ON" << endl;

        if(getAttackingStatus()==false)
        {
            cout << "\nDEMON WILL MISS THE NEXT ATTACK!!!" << endl;
        }
    }
