#include "Creature.h"

Creature::Creature()
{
    //ctor
}

Creature::~Creature()
{
    //dtor
}
