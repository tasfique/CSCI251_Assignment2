#include <iostream>
#include "functions.h"

using namespace std;

//implementing friend function
void initialStatus(Elf elf, Dwarf dwarf)
{
    cout << "\nInitial statuses of the characters: " << endl;
    elf.display();
    cout << endl;
    dwarf.display();
}
