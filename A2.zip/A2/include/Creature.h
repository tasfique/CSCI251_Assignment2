#ifndef CREATURE_H
#define CREATURE_H


class Creature
{
    public:
        Creature();
        virtual ~Creature();

    protected:

    private:
};

#endif // CREATURE_H
