#ifndef DWARF_H
#define DWARF_H
#include "Creature.h"

class Elf;
//declaring derived class
class Dwarf: public Creature
{
    //friend function prototype
    friend void initialStatus(Elf elf, Dwarf dwarf);
private:
    //declaring a data member
    double strengthMultiplier;
public:
    //default constructor
    Dwarf();
    //non-default constructor
    Dwarf(string name, double hitPoints, double strength, bool attackingStatus, double strengthMultiplier);

    //setter
    void setStrengthMultiplier(double strengthMultiplier);

    //getter
    double getStrengthMultiplier();

    //destructor
    ~Dwarf();

    //function to attack an enemy
    void attack(Creature* enemy, int round);

    //function to display the status of the character
    void display();

    //implementing overloaded operator-
    Dwarf operator-(Dwarf dwarf);
    //implementing overloaded operator/
    Dwarf operator/(Dwarf dwarf);
};

#endif
