#include <iostream>
#include "Wizard.h"

//default constructor
    Wizard::Wizard():Creature("Wizard", 80, 10, true)
    {
        wand = false;
    }

    //non-default constructor
    Wizard::Wizard(string name, double hitPoints, double strength, bool attackingStatus, bool wand):Creature(name, hitPoints, strength, attackingStatus), wand(wand){}

    //setter
    void Wizard::setWand(bool wand)
    {
        this->wand = wand;
    }

    //getter
    bool Wizard::getWand()
    {
        return wand;
    }

    //destructor
    Wizard::~Wizard() {}

    //when the wand is on, the opponent will miss his next attack with 90% chance. If the wand is off, the opponent will miss his next attack with 50% chance. Wizard inflicts 10 damages by default
    void Wizard::attack(Creature* enemy, int round)
    {
        if(getWand()==true)
        {
            int randomNum2=(rand()%100)+1;
            cout << randomNum2 << endl;
            if(randomNum2<=90)
            {
                enemy->setAttackingStatus(false);
            }
        }
        else if(getWand()==false)
        {
            int randomNum=(rand()%100)+1;
            if(randomNum<=50)
            {
                enemy->setAttackingStatus(false);
            }
        }

        if(getAttackingStatus()==true)
        {
            enemy->setHitPoints(enemy->getHitPoints() - getStrength());
            if(round%3==0)
            {
                wand=true;
            }
            else
            {
                wand=false;
            }
        }
        else
        {
            setAttackingStatus(true);
        }
    }

    //function to display the status of the character
    void Wizard::display()
    {
        cout << "Name: " << getName() << endl;
        cout << "Hit points: " << getHitPoints() << endl;
        cout << "Strength: " << getStrength() << endl;
        if(getAttackingStatus()==false)
            cout << "Attacking status: NO" << endl;
        else
            cout << "Attacking status: YES" << endl;

        if(getWand()==false)
            cout << "Wand: OFF" << endl;
        else
            cout << "Wand: ON" << endl;

        if(getAttackingStatus()==false)
        {
            cout << "\nWIZARD WILL MISS THE NEXT ATTACK!!!" << endl;
        }
    }
