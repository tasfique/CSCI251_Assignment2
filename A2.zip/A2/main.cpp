//
//  main.cpp
//  Assignment2
//
//  Created by Adilet Kulakhmet on 22/10/2019.
//  Copyright � 2019 Adilet Kulakhmet. All rights reserved.
//

#include <iostream>
#include <ctime>
#include <cstdlib>
#include "Creature.h"
#include "Wizard.h"
#include "Elf.h"
#include "Dwarf.h"
#include "Demon.h"
#include "functions.h"

using namespace std;

int main()
{
    srand(time(0));

    //declaring variables
    char choice1;
    int choiceP1, choiceP2;
    bool winner1=false, winner2=false;

    cout << "********** Welcome to Adilet's RPG game! **********" << endl << endl;;

    do
    {
        //creating array of Creature pointers for Player 1
        Creature * creatures[4];

        //assigning to the array of Creature pointers
        creatures[0] = new Wizard();

        //using overloaded operator+
        Elf elf1, elf2, elf3;
        elf3 = elf1+elf2;

        creatures[1] = &elf3;

        //using overloaded operator-
        Dwarf dwarf1, dwarf2, dwarf3;
        dwarf2 = dwarf1-dwarf3;

        creatures[2] = &dwarf2;
        creatures[3] = new Demon();

        //using dynamic_cast
        Wizard * castedWizard = dynamic_cast<Wizard*>(creatures[0]);
        Elf * castedElf = dynamic_cast<Elf*>(creatures[1]);
        Dwarf * castedDwarf = dynamic_cast<Dwarf*>(creatures[2]);
        Demon * castedDemon = dynamic_cast<Demon*>(creatures[3]);

        //creating the second array of Creature pointers for Player 2
        Creature * creatures2[4];

        //assigning to the array of Creature pointers
        creatures2[0] = new Wizard();

        //using overloaded operator+
        Elf elf4, elf5, elf6;
        elf6 = elf4+elf5;
        creatures2[1] = &elf6;

        //using overloaded operator/
        Dwarf dwarf4, dwarf5, dwarf6;
        dwarf6 = dwarf4/dwarf5;

        creatures2[2] = &dwarf6;
        creatures2[3] = new Demon();

        //using dynamic_cast
        Wizard * castedWizard2 = dynamic_cast<Wizard*>(creatures2[0]);
        Elf * castedElf2 = dynamic_cast<Elf*>(creatures2[1]);
        Dwarf * castedDwarf2 = dynamic_cast<Dwarf*>(creatures2[2]);
        Demon * castedDemon2 = dynamic_cast<Demon*>(creatures2[3]);

        //prompting Player 1 to choose a character
        if(winner1==false)
        {
            cout << "Player 1 is choosing a character:" << endl;
            cout << "1. Wizard" << endl;
            cout << "2. Elf" << endl;
            cout << "3. Dwarf" << endl;
            cout << "4. Demon" << endl;
            cin >> choiceP1;

            //validation
            while(choiceP1<1 || choiceP1>4)
            {
                cout << "Wrong input! Please, try again:" << endl;
                cin >> choiceP1;
            }
        }

        //prompting Player 1 to choose a character
        if(winner2==false)
        {
            cout << "Player 2 is choosing a character:" << endl;
            cout << "1. Wizard" << endl;
            cout << "2. Elf" << endl;
            cout << "3. Dwarf" << endl;
            cout << "4. Demon" << endl;
            cin >> choiceP2;

            //validation
            while(choiceP2<1 || choiceP2>4)
            {
                cout << "Wrong input! Please, try again:" << endl;
                cin >> choiceP2;
            }
        }

        int round=0;

        do
        {
            round++;

            //declaring variables for counting inflicted damage
            double initialHealthP1=creatures[choiceP1-1]->getHitPoints(), initialHealthP2=creatures2[choiceP2-1]->getHitPoints();

            //using friend function
            if((choiceP1==2 && choiceP2==3) && round==1)
            {
                initialStatus(elf3, dwarf6);
            }

            //displaying round
            cout << "\n----------" << endl;
            cout << "Round " << round << ":" << endl;
            cout << "----------" << endl;

            if(round%3==0)
                cout << "*** In this round the characters' skills will be boosted ***" << endl;

            //Player 1's turn to attack
            cout << "\n~~~ Player 1's turn to attack ~~~" << endl;

            //using if else statements to choose the proper character and attack the enemy
            if(choiceP1==1)
            {
                castedWizard->attack(creatures2[choiceP2-1], round);
            }
            else if(choiceP1==2)
            {
                castedElf->attack(creatures2[choiceP2-1], round);
            }
            else if(choiceP1==3)
            {
                castedDwarf->attack(creatures2[choiceP2-1], round);
            }
            else if(choiceP1==4)
            {
                castedDemon->attack(creatures2[choiceP2-1], round);
            }

            //displaying the inflicted damage
            cout << creatures[choiceP1-1]->getName() << " INFLICTED " << initialHealthP2-creatures2[choiceP2-1]->getHitPoints() << " DAMAGES!!!" << endl;

            //displaying the statuses
            creatures[choiceP1-1]->display();
            cout << endl;
            creatures2[choiceP2-1]->display();
            cout << endl;

            //Player 2's turn to attack
            if(creatures[choiceP1-1]->getHitPoints()>0 && creatures2[choiceP2-1]->getHitPoints()>0)
            {
                cout << "~~~ Player 2's turn to attack ~~~" << endl;

                //using if else statements to choose the proper character and attack the enemy
                if(choiceP2==1)
                {
                    castedWizard2->attack(creatures[choiceP1-1], round);
                }
                else if(choiceP2==2)
                {
                    castedElf2->attack(creatures[choiceP1-1], round);
                }
                else if(choiceP2==3)
                {
                    castedDwarf2->attack(creatures[choiceP1-1], round);
                }
                else if(choiceP2==4)
                {
                    castedDemon2->attack(creatures[choiceP1-1], round);
                }

                //displaying the inflicted damage
                cout << creatures2[choiceP2-1]->getName() << " INFLICTED " << initialHealthP1-creatures[choiceP1-1]->getHitPoints() << " DAMAGES!!!" << endl;

                //displaying the statuses
                creatures2[choiceP2-1]->display();
                cout << endl;
                creatures[choiceP1-1]->display();
                cout << endl;
            }

            //prompting user to press 'N' to proceed to the next round
            if(!(creatures[choiceP1-1]->getHitPoints()<1 || creatures2[choiceP2-1]->getHitPoints()<1))
            {
                char next;
                cout << "Please, press 'N' to proceed to the next round: " << endl;
                cin >> next;

                //validation
                while(!(next=='N' || next=='n'))
                {
                    cout << "Wrong input! Please try again:" << endl;
                    cin >> next;
                }
            }

            //identifying which character has been destroyed
            if(creatures[choiceP1-1]->getHitPoints()<1)
            {
                cout << "---------------------------------------------" << endl;
                cout << creatures[choiceP1-1]->getName() << " has been destroyed by " << creatures2[choiceP2-1]->getName() << "!!!" << endl;
                cout << "---------------------------------------------" << endl;

                cout << "PLAYER 2 WON THE GAME!!!" << endl;
                winner1=false;
                winner2=true;

                //deleting the destroyed character's object
                delete creatures[choiceP1-1];
            }
            else if(creatures2[choiceP2-1]->getHitPoints()<1)
            {
                cout << "---------------------------------------------" << endl;
                cout << creatures2[choiceP2-1]->getName() << " has been destroyed by " << creatures[choiceP1-1]->getName() << "!!!" << endl;
                cout << "---------------------------------------------" << endl;

                cout << "PLAYER 1 WON THE GAME!!!" << endl;
                winner1=true;
                winner2=false;

                //deleting the destroyed character's object
                delete creatures2[choiceP2-1];
            }
        }while(creatures[choiceP1-1]->getHitPoints()>0 && creatures2[choiceP2-1]->getHitPoints()>0);

        //asking the winner whether he wants to continue or not
        cout << "The winner wants to continue the game? (y/n)" << endl;
        cin >> choice1;

        //validation
        while(!(choice1=='y' || choice1=='n'))
        {
            cout << "Wrong input! Please, try again: " << endl;
            cin >> choice1;
        }
    }while(choice1!='n');

    return 0;
}
