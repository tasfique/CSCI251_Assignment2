#ifndef DEMON_H
#define DEMON_H
#include "Creature.h"

//declaring derived class
class Demon: public Creature
{
private:
    //declaring a data member
    bool negativeAura;
public:
    //default constructor
    Demon();
    //non-default constructor
    Demon(string name, double hitPoints, double strength, bool attackingStatus, bool negativeAura);
    //setter
    void setNegativeAura(bool negativeAura);
    //getter
    bool getNegativeAura();
    //destructor
    ~Demon();
    //function to attack an enemy
    void attack(Creature* enemy, int round);
    //function to display the status of the character
    void display();
};

#endif
