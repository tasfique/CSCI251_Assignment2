#include <iostream>
#include "Dwarf.h"

Dwarf::Dwarf():Creature("Dwarf", 120, 15, true)
    {
        strengthMultiplier=2;
    }

    //non-default constructor
    Dwarf::Dwarf(string name, double hitPoints, double strength, bool attackingStatus, double strengthMultiplier):Creature(name, hitPoints, strength, attackingStatus), strengthMultiplier(strengthMultiplier){}

    //setter
    void Dwarf::setStrengthMultiplier(double strengthMultiplier)
    {
        this->strengthMultiplier = strengthMultiplier;
    }

    //getter
    double Dwarf::getStrengthMultiplier()
    {
        return strengthMultiplier;
    }

    //destructor
    Dwarf::~Dwarf(){}

    //dwarf has strength multiplier as his special skill. Every 3 rounds the Dwarf's strength will increase by 0.5
    void Dwarf::attack(Creature* enemy, int round)
    {
        if(round%3==0)
        {
            setStrengthMultiplier(getStrengthMultiplier()+0.5);
        }

        if(getAttackingStatus()==true)
        {
            int randomNum=(rand()%100)+1;
            if(randomNum<=90)
            {
                enemy->setHitPoints(enemy->getHitPoints() - getStrength() * getStrengthMultiplier());
            }
            else
            {
                enemy->setHitPoints(enemy->getHitPoints() - getStrength() * getStrengthMultiplier() * 2);
            }
        }
        else if(getAttackingStatus()==false)
        {
            setAttackingStatus(true);
        }
    }

    //function to display the status of the character
    void Dwarf::display()
    {
        cout << "Name: " << getName() << endl;
        cout << "Hit points: " << getHitPoints() << endl;
        cout << "Strength: " << getStrength() << endl;

        if(getAttackingStatus()==false)
            cout << "Attacking status: NO" << endl;
        else
            cout << "Attacking status: YES" << endl;;

        cout << "Strength multiplier: " << getStrengthMultiplier() << endl;

        if(getAttackingStatus()==false)
        {
            cout << "\nDWARF WILL MISS THE NEXT ATTACK!!!" << endl;
        }
    }

    //implementing overloaded operator-
    Dwarf Dwarf::operator-(Dwarf dwarf)
    {
        Dwarf newDwarf;
        newDwarf.setStrengthMultiplier(3);
        newDwarf.strengthMultiplier = newDwarf.strengthMultiplier - dwarf.strengthMultiplier;
        return newDwarf;
    }

    //implementing overloaded operator/
    Dwarf Dwarf::operator/(Dwarf dwarf)
    {
        Dwarf newDwarf;
        newDwarf.strengthMultiplier = newDwarf.strengthMultiplier / dwarf.strengthMultiplier;
        return newDwarf;
    }
