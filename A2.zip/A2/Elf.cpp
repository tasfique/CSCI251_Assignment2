#include <iostream>
#include "Elf.h"

//default constructor
    Elf::Elf():Creature("Elf", 100, 10, true)
    {
        attackingSpeed = 1;
    }

    //default constructor
    Elf::Elf(string name, double hitPoints, double strength, bool attackingStatus, double attackingSpeed):Creature(name, hitPoints, strength, attackingStatus), attackingSpeed(attackingSpeed){}

    //setter
    void Elf::setAttackingSpeed(double attackingSpeed)
    {
        this->attackingSpeed = attackingSpeed;
    }

    //getter
    double Elf::getAttackingSpeed()
    {
        return attackingSpeed;
    }

    //destructor
    Elf::~Elf() {}

    //elf attacks twice by default. Every 3 rounds Elf attacks 3 times
    void Elf::attack(Creature* enemy, int round)
    {
        if(round%3==0)
        {
            setAttackingSpeed(3);
        }
        else
        {
            setAttackingSpeed(2);
        }

        if(getAttackingStatus()==true)
        {
            enemy->setHitPoints(enemy->getHitPoints() - getStrength() * getAttackingSpeed());
        }
        else if(getAttackingStatus()==false)
        {
            setAttackingStatus(true);
        }
    }

    //function to display the status of the character
    void Elf::display()
    {
        cout << "Name: " << getName() << endl;
        cout << "Hit points: " << getHitPoints() << endl;
        cout << "Strength: " << getStrength() << endl;
        if(getAttackingStatus()==false)
            cout << "Attacking status: NO" << endl;
        else
            cout << "Attacking status: YES" << endl;

        cout << "Attacking speed: " << getAttackingSpeed() << endl;

        if(getAttackingStatus()==false)
        {
            cout << "\nELF WILL MISS THE NEXT ATTACK!!!" << endl;
        }
    }

    //implementing overloaded operator+
    Elf Elf::operator+(Elf elf)
    {
        Elf newElf;
        newElf.attackingSpeed = newElf.attackingSpeed + elf.attackingSpeed;
        return newElf;
    }
